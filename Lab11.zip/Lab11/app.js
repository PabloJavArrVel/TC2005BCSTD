const express = require('express');

const comidas = require('./comidas');

const juegos = require('./juegos');

const app = express();

app.use('/comidas', comidas);

app.use('/juegos', juegos);

app.use((request, response, next) => {
    const error = new Error('No hay nada aquí');
    error.status = 404;
    next(error);
  });

app.listen(5000);